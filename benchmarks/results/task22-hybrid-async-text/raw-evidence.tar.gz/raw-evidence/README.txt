Task 22 raw evidence bundle.
Home paths, private IPs, emails, URL credentials, and secret-like assignments were redacted.
source_sha256 identifies the original local file; delivered_sha256 identifies the redacted file.
